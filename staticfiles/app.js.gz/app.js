    // let ul = document.getElementsByClassName("main_body");
    // let li = ul.querySelectorAll('.main_body.main_body_jobs')

let input = document.getElementsByClassName('nav_input');
const listArray = Array.from(li);



// const filterUsers = (event) => {
//   ul.innerHTML = ""
//   let keyword = input.value.toLowerCase();
//   listArray.forEach((item) => {
//     if (item.textContent.toLowerCase().includes(keyword)) {
//       ul.appendChild(item)
//     }
//   })
// }

// input.addEventListener('keyup', filterUsers);








